/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBGpuShader5 {

	/**
	 * Accepted by the &lt;pname&gt; parameter of GetProgramiv: 
	 */
	public static final int GL_GEOMETRY_SHADER_INVOCATIONS = 0x887F;

	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv, GetFloatv,
	 *  GetDoublev, and GetInteger64v:
	 */
	public static final int GL_MAX_GEOMETRY_SHADER_INVOCATIONS = 0x8E5A,
		GL_MIN_FRAGMENT_INTERPOLATION_OFFSET = 0x8E5B,
		GL_MAX_FRAGMENT_INTERPOLATION_OFFSET = 0x8E5C,
		GL_FRAGMENT_INTERPOLATION_OFFSET_BITS = 0x8E5D,
		GL_MAX_VERTEX_STREAMS = 0x8E71;

	private ARBGpuShader5() {}
}
