/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBHalfFloatVertex {

	/**
	 *  Accepted by the &lt;type&gt; argument of VertexPointer, NormalPointer,
	 *  ColorPointer, SecondaryColorPointer, FogCoordPointer, TexCoordPointer,
	 *  and VertexAttribPointer:
	 */
	public static final int GL_HALF_FLOAT = 0x140B;

	private ARBHalfFloatVertex() {}
}
