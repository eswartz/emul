/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class EXTBlendSubtract {

	public static final int GL_FUNC_SUBTRACT_EXT = 0x800A,
		GL_FUNC_REVERSE_SUBTRACT_EXT = 0x800B;

	private EXTBlendSubtract() {}
}
