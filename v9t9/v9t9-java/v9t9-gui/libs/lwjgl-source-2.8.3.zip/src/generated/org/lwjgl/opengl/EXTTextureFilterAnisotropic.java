/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class EXTTextureFilterAnisotropic {

	public static final int GL_TEXTURE_MAX_ANISOTROPY_EXT = 0x84FE,
		GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT = 0x84FF;

	private EXTTextureFilterAnisotropic() {}
}
