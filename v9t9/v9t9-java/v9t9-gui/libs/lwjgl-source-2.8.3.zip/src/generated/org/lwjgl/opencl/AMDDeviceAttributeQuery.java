/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opencl;

import org.lwjgl.*;
import java.nio.*;

public final class AMDDeviceAttributeQuery {

	/**
	 *  Accepted as the &lt;param_name&gt; parameter of clGetDeviceInfo. Return the
	 *  offset in nano-seconds between an event timestamp and Epoch.
	 */
	public static final int CL_DEVICE_PROFILING_TIMER_OFFSET_AMD = 0x4036;

	private AMDDeviceAttributeQuery() {}
}
