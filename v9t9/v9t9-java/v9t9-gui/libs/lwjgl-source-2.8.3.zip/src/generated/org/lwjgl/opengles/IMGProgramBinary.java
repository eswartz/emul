/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class IMGProgramBinary {

	/**
	 * Accepted by the &lt;binaryFormat&gt; parameter of ProgramBinaryOES: 
	 */
	public static final int GL_SGX_PROGRAM_BINARY_IMG = 0x9130;

	private IMGProgramBinary() {}
}
