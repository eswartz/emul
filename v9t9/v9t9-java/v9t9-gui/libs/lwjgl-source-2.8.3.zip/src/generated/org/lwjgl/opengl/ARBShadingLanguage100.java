/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBShadingLanguage100 {

	/**
	 *  Accepted by the &lt;name&gt; parameter of GetString:
	 */
	public static final int GL_SHADING_LANGUAGE_VERSION_ARB = 0x8B8C;

	private ARBShadingLanguage100() {}
}
