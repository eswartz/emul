/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class OESStencil1 {

	/**
	 * Accepted by the &lt;internalformat&gt; parameter of RenderbufferStorageOES: 
	 */
	public static final int GL_STENCIL_INDEX1_OES = 0x8D46;

	private OESStencil1() {}
}
