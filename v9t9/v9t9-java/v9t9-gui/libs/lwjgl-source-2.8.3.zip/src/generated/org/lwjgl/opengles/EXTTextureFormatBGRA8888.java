/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class EXTTextureFormatBGRA8888 {

	/**
	 *  Accepted by the &lt;format> and &lt;internalformat&gt; parameters of TexImage2D
	 *  and the &lt;format&gt; parameter of TexSubImage2D:
	 */
	public static final int GL_BGRA_EXT = 0x80E1;

	private EXTTextureFormatBGRA8888() {}
}
