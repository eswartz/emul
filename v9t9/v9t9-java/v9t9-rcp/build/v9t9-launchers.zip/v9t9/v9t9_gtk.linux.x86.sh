./gtk.linux.x86/v9t9 "$@"

