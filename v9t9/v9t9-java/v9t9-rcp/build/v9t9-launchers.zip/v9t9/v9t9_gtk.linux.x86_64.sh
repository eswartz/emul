./gtk.linux.x86_64/v9t9 "$@"

