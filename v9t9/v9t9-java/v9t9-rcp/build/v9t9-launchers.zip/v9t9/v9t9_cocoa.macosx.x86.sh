./cocoa.macosx.x86/v9t9 "$@"

